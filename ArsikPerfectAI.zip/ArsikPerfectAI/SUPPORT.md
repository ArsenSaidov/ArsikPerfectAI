# Support

If you have questions about the conceptual framework:

- Open an Issue on GitHub (questions only)
- Discuss ideas in a safe, ethical manner
- Avoid technical requests for advanced AI code

This project is for **learning and exploration**, not for building real AI systems.