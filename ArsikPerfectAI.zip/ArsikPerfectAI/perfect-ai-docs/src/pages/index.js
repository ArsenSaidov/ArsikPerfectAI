import React from "react";

export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Arsik Perfect AI Documentation</h1>
      <p>The complete developer guide to the World's First Living Semantic Intelligence System.</p>
    </main>
  );
}