# API Reference
Endpoints for UI → Agent → Core.