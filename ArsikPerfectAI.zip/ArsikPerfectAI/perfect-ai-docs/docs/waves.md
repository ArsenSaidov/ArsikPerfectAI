# Waves 1–10
Description of all AI construction waves.