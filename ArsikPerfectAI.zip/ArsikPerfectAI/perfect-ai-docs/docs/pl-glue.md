# PL-Glue (Pillar XV)
Protection layer mechanism.