# Planner

The Planner transforms user intention into an internal plan:

1. interpret  
2. analyze  
3. respond  