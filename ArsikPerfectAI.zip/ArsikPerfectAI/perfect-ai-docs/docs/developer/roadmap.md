# Project Roadmap

1. Multi-Agent Expansion  
2. Knowledge Graph Engine  
3. Memory Streaming  
4. Live Embedding Models  
5. Plugin Ecosystem  