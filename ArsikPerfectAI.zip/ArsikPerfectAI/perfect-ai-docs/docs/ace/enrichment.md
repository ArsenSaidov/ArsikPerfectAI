# ACE Creative Enrichment

ACE enriches output with creative structure, archetypes,
inspiration vectors, and semantic expansion patterns.