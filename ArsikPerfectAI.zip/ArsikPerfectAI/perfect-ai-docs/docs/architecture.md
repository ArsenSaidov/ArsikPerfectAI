# System Architecture

The Arsik Perfect AI is composed of three core layers:

1. Python Core — The Brain  
2. Node Agent — The Will  
3. Next.js UI — The Face  

All connected through a REST intelligence pipeline.

UI → Agent → Core → Agent → UI
