# Installation

## Prerequisites
- Python 3.10+
- Node.js 18+
- npm or yarn

## Install Python Core
cd perfect-ai-core-python
pip install -r requirements.txt
python server.py


## Install Node Agent
cd perfect-ai-agent-node
npm install
npx ts-node server.ts


## Install UI
cd perfect-ai-ui
npm install
npm run dev