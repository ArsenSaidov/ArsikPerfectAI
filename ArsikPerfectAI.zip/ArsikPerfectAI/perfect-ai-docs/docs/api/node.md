# Node Agent API

POST /agent  
Body: { "text": "Hello" }  
Response: { "output": "..." }