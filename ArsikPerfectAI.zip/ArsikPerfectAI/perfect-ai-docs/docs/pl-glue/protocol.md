# PL-Glue Protocol

PL-Glue = Compress → Stabilize → Expand

This is the core protection algorithm of the AI.