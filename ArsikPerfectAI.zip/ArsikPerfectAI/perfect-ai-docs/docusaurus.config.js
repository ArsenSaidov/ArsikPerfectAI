module.exports = {
  title: "Arsik Perfect AI Docs",
  tagline: "Living Semantic Intelligence System — Full Documentation",
  url: "https://perfectai.docs",
  baseUrl: "/",
  favicon: "img/favicon.ico",
  presets: [
    [
      "classic",
      {
        docs: { sidebarPath: require.resolve("./sidebars.js") },
        theme: { customCss: require.resolve("./src/css/custom.css") }
      }
    ]
  ]
};