module.exports = {
  docs: [
    "intro",
    "installation",
    "architecture",
    "pipeline",

    {
      type: "category",
      label: "Python Core Engine",
      items: [
        "python-core/overview",
        "python-core/modules",
        "python-core/engine",
        "python-core/symbolic",
        "python-core/alignment",
        "python-core/protection",
        "python-core/ace",
        "python-core/reality-grid"
      ]
    },

    {
      type: "category",
      label: "Node Agent System",
      items: [
        "node-agent/overview",
        "node-agent/planner",
        "node-agent/executor",
        "node-agent/memory",
        "node-agent/reflection",
        "node-agent/safety",
        "node-agent/alignment",
        "node-agent/tools",
        "node-agent/protocol"
      ]
    },

    {
      type: "category",
      label: "UI (Next.js)",
      items: [
        "ui/overview",
        "ui/components",
        "ui/chat",
        "ui/panels",
        "ui/api",
        "ui/integration"
      ]
    },

    {
      type: "category",
      label: "PL-Glue",
      items: [
        "pl-glue/protocol",
        "pl-glue/algorithm"
      ]
    },

    {
      type: "category",
      label: "ACE — Creative Engine",
      items: [
        "ace/overview",
        "ace/vectors",
        "ace/archetypes",
        "ace/grid",
        "ace/enrichment",
        "ace/api"
      ]
    },

    {
      type: "category",
      label: "API Reference",
      items: [
        "api/python",
        "api/node",
        "api/ui"
      ]
    },

    {
      type: "category",
      label: "Developer",
      items: [
        "developer/contribute",
        "developer/structure",
        "developer/testing",
        "developer/roadmap"
      ]
    }
  ]
};