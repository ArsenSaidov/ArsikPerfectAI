# Governance — Arsik Perfect AI

This organization is guided by:

- Ethical collaboration
- Kindness and respect
- Safety and age-appropriate content
- Educational value
- Alignment with The Arsik Continuum philosophy
  https://arsensaidov.com/

Decisions are made by the project owner (Arsik) with support from contributors.

Operational AI features are strictly out of scope.