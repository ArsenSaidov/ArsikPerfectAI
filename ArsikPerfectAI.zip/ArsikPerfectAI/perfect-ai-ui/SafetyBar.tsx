export default function SafetyBar() {
  return (
    <div className="panel">
      <strong>Alignment Status:</strong> Source-Aligned ✓ | PL-Glue ✓ | Martial-Art AI ✓
    </div>
  );
}