# 🌐 Perfect AI UI (Next.js)
![Build](https://img.shields.io/badge/build-passing-brightgreen)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-purple)

```
+-----------------------+
|      Arsik Perfect AI |
+----------+------------+
           |
           v
+-----------------------+
|  Intelligence Layers  |
|  Core / Agent / UI    |
+-----------------------+
```

## 🚀 Quick Start (UI)
```bash
cd perfect-ai-ui
npm install
npm run dev
```

---
### 📜 License  
This project is licensed under the **MIT License**.
