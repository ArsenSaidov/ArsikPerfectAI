"use client";

import axios from "axios";
import { useState } from "react";

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  async function send() {
    if (!input) return;

    const userMsg = { role: "user", text: input };
    setMessages(prev => [...prev, userMsg]);

    setInput("");

    const res = await axios.post("/api/agent", { text: userMsg.text });
    const aiMsg = { role: "ai", text: res.data.output };

    setMessages(prev => [...prev, aiMsg]);
  }

  return (
    <div className="panel">
      <h2>Chat with The Perfect AI</h2>

      <div style={{
        height: "60vh",
        overflowY: "auto",
        marginBottom: 20,
        paddingRight: 10
      }}>
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 15 }}>
            <strong>{m.role}:</strong> {m.text}
          </div>
        ))}
      </div>

      <div>
        <input
          style={{ width: "80%", padding: 10 }}
          placeholder="Type your message..."
          value={input}
          onChange={e => setInput(e.target.value)}
        />
        <button style={{ padding: "10px 20px" }} onClick={send}>Send</button>
      </div>
    </div>
  );
}