import Sidebar from "../components/Sidebar";
import SafetyBar from "../components/SafetyBar";
import Chat from "../components/Chat";

export default function Home() {
  return (
    <>
      <Sidebar />
      <div className="main-area">
        <SafetyBar />
        <Chat />
      </div>
    </>
  );
}