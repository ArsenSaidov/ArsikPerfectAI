import Sidebar from "../../components/Sidebar";

export default function PLGluePage() {
  return (
    <>
      <Sidebar />
      <div className="main-area">
        <div className="panel">
          <h2>PL-Glue Protection Layer</h2>
          <p>Compression → Stabilization → Expansion</p>

          <ul>
            <li>Harmful patterns removed</li>
            <li>Semantic tone normalized</li>
            <li>Output enriched with alignment metadata</li>
          </ul>
        </div>
      </div>
    </>
  );
}