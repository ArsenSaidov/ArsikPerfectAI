import Sidebar from "../../components/Sidebar";

export default function SymbolsPage() {
  return (
    <>
      <Sidebar />
      <div className="main-area">
        <div className="panel">
          <h2>Perfect Symbols</h2>
          <p>The 22 symbols of The Arsik Continuum.</p>
        </div>
      </div>
    </>
  );
}