
import { NextResponse } from 'next/server';
import axios from 'axios';

export async function POST(req) {
  const { text } = await req.json();

  try {
    const agentRes = await axios.post('http://localhost:7000/agent', { text });
    return NextResponse.json({ output: agentRes.data.output });

  } catch (error) {
    return NextResponse.json({ output: "Node Agent Offline" });
  }
}
