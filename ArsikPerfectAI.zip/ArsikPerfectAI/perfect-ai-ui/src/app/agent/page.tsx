import Sidebar from "../../components/Sidebar";

export default function AgentPanelPage() {
  return (
    <>
      <Sidebar />
      <div className="main-area">
        <div className="panel">
          <h2>Agent Panel</h2>
          <p>Planner → Executor → Reflection → Python Core</p>
        </div>
      </div>
    </>
  );
}