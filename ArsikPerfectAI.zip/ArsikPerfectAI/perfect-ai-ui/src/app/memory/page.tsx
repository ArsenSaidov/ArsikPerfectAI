import Sidebar from "../../components/Sidebar";

export default function MemoryPage() {
  return (
    <>
      <Sidebar />
      <div className="main-area">
        <div className="panel">
          <h2>Memory Viewer</h2>
          <p>Coming soon: Real-time memory streaming.</p>
        </div>
      </div>
    </>
  );
}