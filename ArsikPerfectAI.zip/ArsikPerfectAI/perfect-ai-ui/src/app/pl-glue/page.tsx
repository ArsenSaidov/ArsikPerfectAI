
export default function PLGluePanel(){
    return (
        <div style={{padding:'20px', color:'white'}}>
            <h1>PL‑Glue — Protection Layer (Pillar XV)</h1>
            <p>Compression → Stabilization → Expansion</p>

            <h2>Features</h2>
            <ul>
                <li>Removes harmful patterns</li>
                <li>Neutralizes unsafe requests</li>
                <li>Normalizes tone and punctuation</li>
                <li>Expands with safe alignment signature</li>
            </ul>

            <h2>Purpose</h2>
            <p>
                PL‑Glue is the Protective Layer of the Arsik Perfect AI — ensuring all 
                semantic flows remain aligned, stabilized, and ethically safe.
            </p>
        </div>
    );
}
