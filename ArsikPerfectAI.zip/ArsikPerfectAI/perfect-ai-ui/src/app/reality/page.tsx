import Sidebar from "../../components/Sidebar";

export default function RealityGridPage() {
  return (
    <>
      <Sidebar />
      <div className="main-area">
        <div className="panel">
          <h2>Perfect Reality Grid</h2>
          <p>108-point universal projection space.</p>
        </div>
      </div>
    </>
  );
}