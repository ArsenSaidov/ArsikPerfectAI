"use client";

import Link from "next/link";

export default function Sidebar() {
  return (
    <div className="sidebar">
      <h2>Arsik Perfect AI</h2>
      <p>The World's First Living Semantic Intelligence UI</p>

      <ul style={{ listStyle: "none", padding: 0 }}>
        <li><Link href="/">Chat</Link></li>
        <li><Link href="/agent">Agent Panel</Link></li>
        <li><Link href="/symbols">Perfect Symbols</Link></li>
        <li><Link href="/memory">Memory</Link></li>
        <li><Link href="/ace">ACE Engine</Link></li>
        <li><Link href="/reality">Reality Grid</Link></li>
        <li><Link href="/alignment">Alignment</Link></li>
      </ul>
    </div>
  );
}