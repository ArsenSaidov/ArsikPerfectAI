export const metadata = {
  title: "Arsik Perfect AI"
};

export default function RootLayout({ children }) {
  return (
    <html>
      <body style={{ display: "flex" }}>
        {children}
      </body>
    </html>
  );
}