
import express from 'express';
import bodyParser from 'body-parser';
import axios from 'axios';
import { PerfectAIAgent } from './src/agent/Agent.js';

const app = express();
app.use(bodyParser.json());

const agent = new PerfectAIAgent();

app.post('/agent', async (req, res) => {
  const text = req.body.text || "";

  try {
    const intermediate = await agent.process(text);

    const py = await axios.post('http://localhost:5000/core', { text: intermediate });

    res.json({ output: py.data.output });

  } catch (err) {
    res.json({ output: "Python Core Offline or Integration Error" });
  }
});

app.listen(7000, () => {
  console.log("Perfect AI Node Agent running on port 7000");
});
