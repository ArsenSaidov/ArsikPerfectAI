export function mathTool({ expression }) {
    try {
        return eval(expression);
    } catch {
        return "Math error";
    }
}