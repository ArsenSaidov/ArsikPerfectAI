export function fileTool({ path }) {
    return "File access disabled in this build.";
}