export async function webTool({ query }) {
    return "Web search unavailable in offline mode.";
}