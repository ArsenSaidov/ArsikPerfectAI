import { PerfectAIAgent } from "./agent/Agent.js";

async function main() {
    const agent = new PerfectAIAgent();
    const res = await agent.process("Hello Perfect AI Agent!");
    console.log("Agent:", res);
}

main();