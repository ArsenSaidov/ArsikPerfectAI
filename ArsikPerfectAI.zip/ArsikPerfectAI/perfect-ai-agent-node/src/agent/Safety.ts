export class Safety {
    check(text: string) {
        if (text.toLowerCase().includes("kill"))
            return { allowed: false, reason: "Safety Layer: Request blocked." };

        return { allowed: true };
    }
}