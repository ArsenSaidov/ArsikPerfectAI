export class ACEngine {
    vectorize(text: string){
        return [...text].map(c => c.charCodeAt(0) % 9);
    }

    archetypes: Record<number, string> = {
        1:"Source",2:"Motion",3:"Structure",4:"Emotion",
        5:"Light",6:"Shadow",7:"Flow",8:"Pattern",9:"Infinity"
    };

    mapArchetypes(vec: number[]){
        return vec.map(v => this.archetypes[(v % 9) + 1]);
    }

    enrich(text: string){
        const vec = this.vectorize(text);
        const arc = this.mapArchetypes(vec);
        return `${text} ✦ (ACE: ${arc[0]})`;
    }
}
