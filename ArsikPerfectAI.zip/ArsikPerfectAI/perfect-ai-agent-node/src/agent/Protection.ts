export class ProtectionLayer {
    compress(text: string) {
        return text
            .replace(/kill|attack|destroy|hack/gi, "[blocked]")
            .trim();
    }

    stabilize(text: string) {
        if (text.includes("[blocked]")) {
            return "This request contained unsafe patterns and was neutralized.";
        }
        return text;
    }

    expand(text: string) {
        return text + " (PL-Glue Verified)";
    }

    filter(text: string) {
        return this.expand(this.stabilize(this.compress(text)));
    }
}