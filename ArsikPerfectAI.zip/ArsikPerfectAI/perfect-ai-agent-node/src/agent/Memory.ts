export class Memory {
    history: any[] = [];

    store(role: string, text: string) {
        this.history.push({ role, text, time: Date.now() });
    }

    getHistory() {
        return this.history;
    }
}