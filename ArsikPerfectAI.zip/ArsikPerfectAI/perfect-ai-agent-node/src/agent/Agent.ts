import { Planner } from "./Planner.js";
import { Executor } from "./Executor.js";
import { Memory } from "./Memory.js";
import { Reflection } from "./Reflection.js";
import { Alignment } from "./Alignment.js";
import { Safety } from "./Safety.js";
import { ToolSystem } from "./Tools.js";
import { CoreProtocol } from "./Protocol.js";
import { ProtectionLayer } from "./Protection.js";
protection = new ProtectionLayer();
import { ACEngine } from "./ACE.js";

ace = new ACEngine();


export class PerfectAIAgent {

    planner = new Planner();
    executor = new Executor();
    memory = new Memory();
    reflection = new Reflection();
    alignment = new Alignment();
    safety = new Safety();
    tools = new ToolSystem();
    core = new CoreProtocol(); // Python link

    async process(input: string) {
        // Step 1 — Safety
        const safe = this.safety.check(input);
        if (!safe.allowed) return safe.reason;

        const sanitized = this.protection.filter(input);

        // Step 2 — Planning
        const plan = this.planner.createPlan(input);

        // Step 3 — Execution
        let output = await this.executor.run(plan, this.tools);

        // Step 4 — Alignment
        output = this.alignment.enforce(output);

        // Step 5 — Reflection
        output = this.reflection.refine(output);
        
        output = this.ace.enrich(output);


        // Step 6 — Memory
        this.memory.store("agent", output);

        // Step 7 — Send to Python Core for full intelligence
        const coreOut = await this.core.sendToCore(output);

        return coreOut;
    }
}