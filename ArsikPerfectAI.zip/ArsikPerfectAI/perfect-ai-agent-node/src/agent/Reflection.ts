export class Reflection {
    refine(output: string) {
        return output + " [Reflected]";
    }
}