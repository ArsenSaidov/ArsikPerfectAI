
export class PLGlue {

    compress(text: string){
        const patterns = /(kill|attack|destroy|hack|explode|hurt)/gi;
        text = text.replace(patterns, "[blocked]");
        text = text.replace(/!{2,}/g, "!");
        return text.trim();
    }

    stabilize(text: string){
        if(text.includes("[blocked]")){
            return "Unsafe request → Neutralized by PL‑Glue.";
        }
        return text.replace(/\?\?/g,"?").replace(/\.\./g,".");
    }

    expand(text: string){
        return text + " (PL‑Glue ✓ Verified)";
    }

    filter(text: string){
        return this.expand(this.stabilize(this.compress(text)));
    }
}
