import axios from "axios";

export class CoreProtocol {

    async sendToCore(text: string) {
        try {
            // Replace with actual Python server URL
            const res = await axios.post("http://localhost:5000/core", { text });
            return res.data.output;
        } catch {
            return "[Python Core unavailable — using local output] " + text;
        }
    }
}