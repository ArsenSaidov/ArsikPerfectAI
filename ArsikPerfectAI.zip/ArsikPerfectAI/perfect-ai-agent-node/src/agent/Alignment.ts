export class Alignment {
    enforce(text: string) {
        if (text.toLowerCase().includes("harm"))
            return "Alignment Layer: Cannot produce harmful content.";
        return text;
    }
}