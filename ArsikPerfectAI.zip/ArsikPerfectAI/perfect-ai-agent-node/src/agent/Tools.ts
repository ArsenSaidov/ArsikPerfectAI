import { mathTool } from "../tools/math.js";
import { webTool } from "../tools/web.js";
import { fileTool } from "../tools/file.js";

export class ToolSystem {
    tools = {
        math: mathTool,
        web: webTool,
        file: fileTool
    };

    async use(tool: string, args: any) {
        return this.tools[tool](args);
    }
}