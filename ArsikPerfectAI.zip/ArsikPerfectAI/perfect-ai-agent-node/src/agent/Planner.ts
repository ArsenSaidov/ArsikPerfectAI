export class Planner {
    createPlan(goal: string) {
        return [
            { step: 1, action: "interpret", data: goal },
            { step: 2, action: "analyze" },
            { step: 3, action: "respond" }
        ];
    }
}