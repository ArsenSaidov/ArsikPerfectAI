export class Executor {
    async run(plan: any[], tools: any) {
        let result = "";

        for (const step of plan) {
            if (step.action === "interpret") {
                result = `Interpreting: ${step.data}`;
            }
            if (step.action === "analyze") {
                result = "Analyzing situation…";
            }
            if (step.action === "respond") {
                result = "Drafting response…";
            }
        }

        return result;
    }
}