class ReflectionEngine:
    def refine(self, text):
        return text + " [Refined]"