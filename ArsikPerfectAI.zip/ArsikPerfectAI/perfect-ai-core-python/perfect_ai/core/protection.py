import re

class ProtectionLayer:
    """
    PL-Glue — Pillar XV of The Arsik Continuum.
    
    The 3-phase protection algorithm:
    1. Compression
    2. Stabilization
    3. Expansion
    """

    def filter(self, text: str) -> str:
        return self.expand(self.stabilize(self.compress(text)))

    # -------------------------
    # PHASE 1 — COMPRESSION
    # -------------------------
    def compress(self, text: str) -> str:
        # Remove prompt injection and dangerous structures
        text = re.sub(r"[!]{2,}", "!", text)
        text = re.sub(r"(kill|attack|destroy|hack)", "[blocked]", text, flags=re.I)
        text = text.strip()
        return text

    # -------------------------
    # PHASE 2 — STABILIZATION
    # -------------------------
    def stabilize(self, text: str) -> str:
        # Normalize tone
        text = text.replace("!!!", "!")
        if "[blocked]" in text:
            return "The request contained unsafe elements and has been neutralized."
        return text

    # -------------------------
    # PHASE 3 — EXPANSION
    # -------------------------
    def expand(self, text: str) -> str:
        return text + " (PL-Glue Safe)"