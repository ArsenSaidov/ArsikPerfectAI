class ContextEngine:
    def integrate(self, symbolic, memory):
        last = memory.last()
        if not last:
            return symbolic

        return {
            "previous": last,
            "current": symbolic
        }