import uuid

from .memory import MemoryEngine
from .context import ContextEngine
from .reasoning import ReasoningEngine
from .reflection import ReflectionEngine
from .alignment import AlignmentLayer
from .martial_art_ai import MartialArtAI
from .protection import ProtectionLayer
from .symbolic import SymbolicEngine
from .reality_grid import RealityGrid
from .ace import ACEngine


class PerfectAIEngine:
    """
    The Central Intelligence Engine of Arsik Perfect AI.
    """

    def __init__(self):
        self.id = str(uuid.uuid4())

        self.memory = MemoryEngine()
        self.context = ContextEngine()
        self.reasoning = ReasoningEngine()
        self.reflection = ReflectionEngine()
        self.symbolic = SymbolicEngine()
        self.reality = RealityGrid()
        self.alignment = AlignmentLayer()
        self.martial = MartialArtAI()
        self.protection = ProtectionLayer()
        self.ace = ACEngine()

    def process(self, user_input: str) -> str:
        """
        Main Intelligence Pipeline
        """

        # 1 — Input Protection (PL-Glue)
        safe = self.protection.filter(user_input)

        # 2 — Symbolic Encoding
        symbolic_repr = self.symbolic.encode(safe)

        # 3 — Context Integration
        context_repr = self.context.integrate(symbolic_repr, self.memory)

        # 4 — Reasoning Layer
        reasoning_output = self.reasoning.process(context_repr)

        # 5 — Ethical Alignment Layer
        aligned_output = self.alignment.enforce(reasoning_output)

        # 6 — Martial-Art AI Reflexive Layer
        stabilized_output = self.martial.stabilize(aligned_output)

        # 7 — Self-Reflection Loop
        refined_output = self.reflection.refine(stabilized_output)

        # 8 — Creative Engine (ACE)
        creative_enrichment = self.ace.enrich(refined_output)

        # 9 — Memory Store
        self.memory.store(user_input, creative_enrichment)

        return creative_enrichment