class MemoryEngine:
    def __init__(self):
        self.history = []

    def store(self, user_input, output):
        self.history.append({
            "user": user_input,
            "output": output
        })

    def last(self):
        return self.history[-1] if self.history else None