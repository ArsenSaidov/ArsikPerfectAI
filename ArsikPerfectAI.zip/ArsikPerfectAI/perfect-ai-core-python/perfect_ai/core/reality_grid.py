class RealityGrid:
    def project(self, vector):
        return sum(vector) % 108