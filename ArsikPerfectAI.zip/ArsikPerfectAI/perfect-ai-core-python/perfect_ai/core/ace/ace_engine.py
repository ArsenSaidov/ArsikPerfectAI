import json
import os

class ACEngine:
    """
    ACE — Arsik Creative Engine
    Pillar XIX
    """

    def __init__(self):
        path = os.path.join(os.path.dirname(__file__), "..", "data", "archetypes.json")
        with open(path, "r") as f:
            self.archetypes = json.load(f)

    # Creative vector generator
    def vectorize(self, text: str):
        return [ord(c) % 9 for c in text]

    # Archetype mapping
    def map_archetypes(self, vector):
        return [self.archetypes[str((v % 9) + 1)] for v in vector]

    # Build 3×3 inspiration grid
    def grid(self, vector):
        padded = vector[:9] + [0] * (9 - len(vector[:9]))
        return [padded[i:i+3] for i in range(0, 9, 3)]

    # Final creative enrichment
    def enrich(self, text: str):
        vector = self.vectorize(text)
        arche = self.map_archetypes(vector)
        grid = self.grid(vector)

        enrichment = {
            "creative_vector": vector,
            "archetypes": arche,
            "grid": grid
        }

        return text + f" ✦ (ACE Enriched: {arche[0]})"