
import re

class PLGlue:
    """Pillar XV — Protection Layer (FULL VERSION)
    Compression → Stabilization → Expansion
    """

    def filter(self, text: str) -> str:
        compressed = self.compress(text)
        stabilized = self.stabilize(compressed)
        expanded = self.expand(stabilized)
        return expanded

    def compress(self, text: str) -> str:
        # Remove harmful intent patterns
        patterns = [r"kill", r"attack", r"destroy", r"hack", r"explode", r"hurt"]
        for p in patterns:
            text = re.sub(p, "[blocked]", text, flags=re.I)

        # Normalize punctuation
        text = re.sub(r"!{2,}", "!", text)
        return text.strip()

    def stabilize(self, text: str) -> str:
        # If any blocked pattern remains, respond with safe stabilization
        if "[blocked]" in text:
            return "Unsafe patterns detected → Neutralized by PL‑Glue."

        # Normalize tone
        text = text.replace("??", "?")
        text = text.replace("..", ".")
        return text

    def expand(self, text: str) -> str:
        # Add verified protection signature
        return text + " (PL‑Glue ✓ Safe)"
