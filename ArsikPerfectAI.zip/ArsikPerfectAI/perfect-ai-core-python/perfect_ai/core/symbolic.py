import json
import os

class SymbolicEngine:
    def __init__(self):
        path = os.path.join(os.path.dirname(__file__), "..", "data", "perfect_symbols.json")
        with open(path, "r") as f:
            self.symbols = json.load(f)

    def encode(self, text):
        return [ord(c) % 22 for c in text]

    def decode(self, seq):
        return "".join(chr(i + 65) for i in seq)