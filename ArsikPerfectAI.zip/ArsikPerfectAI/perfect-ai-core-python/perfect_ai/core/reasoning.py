class ReasoningEngine:
    def process(self, context):
        return f"Reasoned output: {context}"