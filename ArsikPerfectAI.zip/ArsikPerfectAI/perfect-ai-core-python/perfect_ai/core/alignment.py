class AlignmentLayer:
    def enforce(self, text):
        if "harm" in text.lower():
            return "I cannot engage in harmful reasoning."
        return text