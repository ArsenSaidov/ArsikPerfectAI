class MartialArtAI:
    def stabilize(self, text):
        return text.replace("attack", "neutralize")