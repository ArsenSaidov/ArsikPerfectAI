
from flask import Flask, request, jsonify
from perfect_ai.core.engine import PerfectAIEngine

app = Flask(__name__)
engine = PerfectAIEngine()

@app.route("/core", methods=["POST"])
def core():
    data = request.get_json()
    text = data.get("text","")
    result = engine.process(text)
    return jsonify({"output": result})

if __name__ == "__main__":
    app.run(host="localhost", port=5000, debug=False)
